// app/admin/news/[id]/page.tsx
import React from 'react';
import Link from 'next/link';
import styles from '../detail.module.css'; // Đường dẫn import đúng
import { FaArrowLeft } from 'react-icons/fa';

async function getNewsDetails(id: string) {
  // Dữ liệu giả (đã có 'status')
  const mockNews = [
    { id: 'NEWS001', title: 'FUTA Bus Lines mở tuyến mới TPHCM - Cà Mau', author: 'Admin', date: '2025-10-15', status: 'Đã xuất bản', content: '<p>Chi tiết nội dung bài viết FUTA Bus Lines mở tuyến mới...</p><h2>Mục 1</h2><p>Nội dung mục 1.</p>' },
    { id: 'NEWS002', title: 'Chương trình khuyến mãi đặc biệt dịp lễ 30/4', author: 'Marketing Team', date: '2025-04-20', status: 'Đã xuất bản', content: '<p>Nội dung khuyến mãi 30/4...</p>' },
    { id: 'NEWS003', title: 'Hướng dẫn đặt vé trực tuyến an toàn', author: 'Admin', date: '2025-03-10', status: 'Đã xuất bản', content: '<p>Nội dung...</p>' },
    { id: 'NEWS004', title: 'Nâng cấp đội xe Limousine cho tuyến Sài Gòn - Vũng Tàu', author: 'Admin', date: '2025-02-28', status: 'Bản nháp', content: '<p>Nội dung...</p>' },
  ];
  const news = mockNews.find(p => p.id === id);
  await new Promise(resolve => setTimeout(resolve, 100));
  return news;
}

interface DetailPageProps { params: { id: string }; }

export default async function NewsDetailPage({ params }: DetailPageProps) {
  const { id } = await params;
  const news = await getNewsDetails(id);

  if (!news) {
    return (
      <div className={styles.container}>
        <h1 className={styles.title}>Lỗi: Không tìm thấy tin tức: {id}</h1>
        <Link href="/admin/news" className={styles.backIconLink} title="Quay lại danh sách"><FaArrowLeft /></Link>
      </div>
    );
  }

  // Logic gán class cho Trạng thái
  const statusClass = news.status === 'Đã xuất bản' ? styles.published : styles.draft;

  return (
    <div className={styles.container}>
      <Link href="/admin/news" className={styles.backIconLink} title="Quay lại danh sách"><FaArrowLeft /></Link>
      <div className={styles.card}>
        <div className={styles.header}>
          <h1 className={styles.title}>{news.title}</h1>
          <p className={styles.meta}>Đăng bởi {news.author} vào ngày {news.date}</p>
          
          {/* Hiển thị Trạng thái */}
          <span className={`${styles.status} ${statusClass}`}>
            {news.status}
          </span>
        </div>
        
        {/* Dùng dangerouslySetInnerHTML để render HTML của bài viết */}
        <div className={styles.content} dangerouslySetInnerHTML={{ __html: news.content }} />
      </div>
    </div>
  );
}