// app/admin/promotions/[id]/page.tsx
import React from 'react';
import Link from 'next/link';
import styles from '../detail.module.css'; // Sửa đường dẫn import
import { FaArrowLeft } from 'react-icons/fa';

async function getPromotionDetails(id: string) {
  const mockPromotions = [
    { id: 'KM001', code: 'FUTA10', description: 'Giảm 10% cho tuyến TP.HCM - Đà Lạt', discountType: 'Phần trăm', value: '10%', startDate: '2025-10-01', endDate: '2025-10-31', status: 'Đang hoạt động', maxUsage: 1000, customerGroup: 'Tất cả' },
    { id: 'KM002', code: 'CHAOMUNG', description: 'Giảm 20,000đ cho khách hàng mới', discountType: 'Số tiền cố định', value: '20,000đ', startDate: '2025-09-15', endDate: '2025-12-31', status: 'Đang hoạt động', maxUsage: 500, customerGroup: 'Khách hàng mới' },
    { id: 'KM003', code: 'SINHNHAT', description: 'Giảm 50,000đ trong tháng sinh nhật', discountType: 'Số tiền cố định', value: '50,000đ', startDate: '2025-01-01', endDate: '2025-12-31', status: 'Đang hoạt động', maxUsage: 200, customerGroup: 'Khách hàng thân thiết' },
    { id: 'KM004', code: 'HE2025', description: 'Giảm giá vé hè', discountType: 'Phần trăm', value: '15%', startDate: '2025-06-01', endDate: '2025-08-31', status: 'Đã hết hạn', maxUsage: 2000, customerGroup: 'Tất cả' },
  ];
  const promotion = mockPromotions.find(p => p.id === id);
  await new Promise(resolve => setTimeout(resolve, 100));
  return promotion;
}

interface DetailPageProps { params: { id: string }; }

export default async function PromotionDetailPage({ params }: DetailPageProps) {
  const { id } = await params; // Sửa lỗi await
  const promo = await getPromotionDetails(id);

  if (!promo) {
    return (
      <div className={styles.container}>
        <h1 className={styles.title}>Lỗi: Không tìm thấy ID: {id}</h1>
        <Link href="/admin/promotions" className={styles.backIconLink} title="Quay lại danh sách"><FaArrowLeft /></Link>
      </div>
    );
  }
  const statusClass = promo.status === 'Đang hoạt động' ? styles.active : styles.expired;

  return (
    <div className={styles.container}>
      <Link href="/admin/promotions" className={styles.backIconLink} title="Quay lại danh sách"><FaArrowLeft /></Link>
      <div className={styles.card}>
        <div className={styles.header}><h1 className={styles.title}>Chi tiết Khuyến mãi</h1></div>
        <div className={styles.content}>
          <div className={styles.grid}>
            <div className={styles.infoItem}><label className={styles.label}>Mã KM</label><p className={styles.value}>{promo.id}</p></div>
            <div className={styles.infoItem}><label className={styles.label}>Mã Code</label><p className={styles.valueCode}>{promo.code}</p></div>
            <div className={styles.infoItem}><label className={styles.label}>Loại giảm giá</label><p className={styles.value}>{promo.discountType}</p></div>
            <div className={styles.infoItem}><label className={styles.label}>Giá trị</label><p className={styles.value}>{promo.value}</p></div>
            <div className={styles.infoItem}><label className={styles.label}>Ngày bắt đầu</label><p className={styles.value}>{promo.startDate}</p></div>
            <div className={styles.infoItem}><label className={styles.label}>Ngày kết thúc</label><p className={styles.value}>{promo.endDate}</p></div>
            <div className={styles.infoItem}><label className={styles.label}>Số lượng tối đa</label><p className={styles.value}>{promo.maxUsage.toString()}</p></div>
            <div className={styles.infoItem}><label className={styles.label}>Nhóm khách hàng</label><p className={styles.value}>{promo.customerGroup}</p></div>
            <div className={styles.infoItem}><label className={styles.label}>Trạng thái</label><span className={`${styles.status} ${statusClass}`}>{promo.status}</span></div>
            <div className={styles.description}><label className={styles.label}>Mô tả</label><p className={styles.value}>{promo.description}</p></div>
          </div>
        </div>
      </div>
    </div>
  );
}