// app/admin/(dashboard)/invoices/page.tsx
import React from 'react';
import Link from 'next/link';
import styles from '../../invoices/invoices.module.css'; 
import { FaSearch, FaEye, FaPrint } from 'react-icons/fa';
// THÊM: Import Search và Pagination
import Search from '../../_components/Search';
import Pagination from '../../_components/Pagination';

const ITEMS_PER_PAGE = 5;

// Dữ liệu giả
const mockInvoices = [
  { id: 'HD001', customerName: 'Nguyễn Văn A', tripInfo: 'TP. HCM - Đà Lạt', total: 250000, date: '2025-10-20', status: 'Đã thanh toán' },
  { id: 'HD002', customerName: 'Trần Thị B', tripInfo: 'Hà Nội - Hải Phòng', total: 100000, date: '2025-10-22', status: 'Chưa thanh toán' },
  { id: 'HD003', customerName: 'Lê Văn C', tripInfo: 'Đà Nẵng - Huế', total: 70000, date: '2025-10-15', status: 'Đã hủy' },
  { id: 'HD004', customerName: 'Phạm Thị D', tripInfo: 'TP. HCM - Vũng Tàu', total: 150000, date: '2025-10-24', status: 'Đã thanh toán' },
  { id: 'HD005', customerName: 'Nguyễn Văn A', tripInfo: 'TP. HCM - Cần Thơ', total: 180000, date: '2025-10-25', status: 'Đã thanh toán' },
];

// SỬA: Hàm lấy dữ liệu
async function getInvoices(query: string, currentPage: number) {
  const filteredInvoices = mockInvoices.filter((invoice) =>
    invoice.id.toLowerCase().includes(query.toLowerCase()) ||
    invoice.customerName.toLowerCase().includes(query.toLowerCase())
  );

  const totalPages = Math.ceil(filteredInvoices.length / ITEMS_PER_PAGE);
  const offset = (currentPage - 1) * ITEMS_PER_PAGE;
  const invoices = filteredInvoices.slice(offset, offset + ITEMS_PER_PAGE);

  return { invoices, totalPages };
}

// SỬA: Thêm props searchParams và 'await'
const InvoicesPage = async ({
  searchParams,
}: {
  searchParams?: Promise<{
    query?: string;
    page?: string;
  }>;
}) => {
  const awaitedParams = await searchParams; 
  const query = awaitedParams?.query || '';
  const currentPage = Number(awaitedParams?.page) || 1;

  const { invoices, totalPages } = await getInvoices(query, currentPage);

  return (
    <div className={styles.container}>
      <div className={styles.header}>
        <h1 className={styles.title}>Quản lý Hóa đơn</h1>
      </div>
      
      {/* THÊM: Component Search */}
      <div className={styles.toolbar}>
        <Search placeholder="Tìm kiếm (mã HĐ, tên khách hàng...)" />
      </div>

      <div className={styles.tableWrapper}>
        <table className={styles.table}>
          <thead>
            <tr>
              <th>Mã HĐ</th>
              <th>Ngày đặt</th>
              <th>Trạng thái</th>
              <th>Hành động</th>
            </tr>
          </thead>
          <tbody>
            {/* SỬA: map từ invoices */}
            {invoices.map((invoice) => (
              <tr key={invoice.id}>
                <td>{invoice.id}</td>
                <td>{invoice.date}</td>
                <td>
                  <span className={`${styles.status} ${styles[invoice.status.replace(/\s+/g, '').toLowerCase()]}`}>
                    {invoice.status}
                  </span>
                </td>
                <td>
                  <div className={styles.actions}>
                    <Link href={`/admin/invoices/${invoice.id}`} className={`${styles.actionButton} ${styles.viewButton}`} title="Xem chi tiết"><FaEye /></Link>
                    <Link href={`/admin/invoices/${invoice.id}`} className={`${styles.actionButton} ${styles.printButton}`} title="In hóa đơn"><FaPrint /></Link>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      
      {/* THÊM: Component Pagination */}
      <Pagination totalPages={totalPages} />
    </div>
  );
};
export default InvoicesPage;