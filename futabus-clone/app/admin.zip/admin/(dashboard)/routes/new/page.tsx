// app/admin/(dashboard)/routes/new/page.tsx
"use client"; 
import React from 'react';
import Link from 'next/link';
import styles from '../../../routes/form.module.css';

export default function CreateRoutePage() {
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    alert('Đã tạo tuyến xe mới!');
  };

  return (
    <div className={styles.card}>
      <div className={styles.header}><h1 className={styles.title}>Thêm tuyến xe mới</h1></div>
      <form className={styles.form} onSubmit={handleSubmit}>
        <div className={styles.grid}>
          <div className={styles.formGroup}><label htmlFor="id" className={styles.label}>Mã tuyến</label><input type="text" id="id" name="id" className={styles.input} placeholder="Ví dụ: ROUTE05" required /></div>
          <div className={styles.formGroup}><label htmlFor="name" className={styles.label}>Tên tuyến</label><input type="text" id="name" name="name" className={styles.input} placeholder="Ví dụ: Cần Thơ - Bạc Liêu" required /></div>
          <div className={styles.formGroup}><label htmlFor="start" className={styles.label}>Điểm đi</label><input type="text" id="start" name="start" className={styles.input} placeholder="Ví dụ: Bến xe Cần Thơ" required /></div>
          <div className={styles.formGroup}><label htmlFor="end" className={styles.label}>Điểm đến</label><input type="text" id="end" name="end" className={styles.input} placeholder="Ví dụ: Bến xe Bạc Liêu" required /></div>
          <div className={styles.formGroup}><label htmlFor="distance" className={styles.label}>Khoảng cách</label><input type="text" id="distance" name="distance" className={styles.input} placeholder="Ví dụ: 150 km" /></div>
          <div className={styles.formGroup}><label htmlFor="time" className={styles.label}>Thời gian ước tính</label><input type="text" id="time" name="time" className={styles.input} placeholder="Ví dụ: 3 giờ" /></div>
          <div className={styles.actions}>
            <Link href="/admin/routes" className={`${styles.button} ${styles.cancelButton}`}>Hủy</Link>
            <button type="submit" className={`${styles.button} ${styles.saveButton}`}>Lưu tuyến xe</button>
          </div>
        </div>
      </form>
    </div>
  );
}