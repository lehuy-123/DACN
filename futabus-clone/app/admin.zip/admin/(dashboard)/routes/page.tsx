// app/admin/(dashboard)/routes/page.tsx
import React from 'react';
import Link from 'next/link';
import styles from '../../routes/routes.module.css'; 
import { FaEdit, FaTrash, FaSearch, FaEye, FaPlus } from 'react-icons/fa';
// THÊM: Import Search và Pagination
import Search from '../../_components/Search';
import Pagination from '../../_components/Pagination';

const ITEMS_PER_PAGE = 5;

// Dữ liệu giả
const mockRoutes = [
  { id: 'ROUTE01', name: 'TP. HCM - Đà Lạt', distance: '308 km', time: '8 giờ' },
  { id: 'ROUTE02', name: 'TP. HCM - Vũng Tàu', distance: '96 km', time: '2.5 giờ' },
  { id: 'ROUTE03', name: 'Hà Nội - Hải Phòng', distance: '125 km', time: '2 giờ' },
  { id: 'ROUTE04', name: 'Đà Nẵng - Huế', distance: '93 km', time: '2 giờ' },
  { id: 'ROUTE05', name: 'Sài Gòn - Cần Thơ', distance: '169 km', time: '4 giờ' },
  { id: 'ROUTE06', name: 'Sài Gòn - Rạch Giá', distance: '245 km', time: '6 giờ' },
];

// SỬA: Hàm lấy dữ liệu
async function getRoutes(query: string, currentPage: number) {
  const filteredRoutes = mockRoutes.filter((route) =>
    route.id.toLowerCase().includes(query.toLowerCase()) ||
    route.name.toLowerCase().includes(query.toLowerCase())
  );

  const totalPages = Math.ceil(filteredRoutes.length / ITEMS_PER_PAGE);
  const offset = (currentPage - 1) * ITEMS_PER_PAGE;
  const routes = filteredRoutes.slice(offset, offset + ITEMS_PER_PAGE);

  return { routes, totalPages };
}

// SỬA: Thêm props searchParams và 'await'
const RoutesPage = async ({
  searchParams,
}: {
  searchParams?: Promise<{
    query?: string;
    page?: string;
  }>;
}) => {
  const awaitedParams = await searchParams; 
  const query = awaitedParams?.query || '';
  const currentPage = Number(awaitedParams?.page) || 1;

  const { routes, totalPages } = await getRoutes(query, currentPage);

  return (
    <div className={styles.container}>
      <div className={styles.header}>
        <h1 className={styles.title}>Quản lý Tuyến xe</h1>
        <Link href="/admin/routes/new" className={styles.addButton} title="Thêm tuyến xe mới">
          <FaPlus />
        </Link>
      </div>
      
      {/* THÊM: Component Search */}
      <div className={styles.toolbar}>
        <Search placeholder="Tìm kiếm (mã tuyến, tên tuyến...)" />
      </div>

      <div className={styles.tableWrapper}>
        <table className={styles.table}>
          <thead>
            <tr>
              <th>Mã tuyến</th>
              <th>Tên tuyến</th>
              <th>Khoảng cách</th>
              <th>Hành động</th>
            </tr>
          </thead>
          <tbody>
            {/* SỬA: map từ routes */}
            {routes.map((route) => (
              <tr key={route.id}>
                <td>{route.id}</td>
                <td>{route.name}</td>
                <td>{route.distance}</td>
                <td>
                  <div className={styles.actions}>
                    <Link href={`/admin/routes/${route.id}`} className={`${styles.actionButton} ${styles.viewButton}`} title="Xem chi tiết"><FaEye /></Link>
                    <Link href={`/admin/routes/edit/${route.id}`} className={`${styles.actionButton} ${styles.editButton}`} title="Chỉnh sửa"><FaEdit /></Link>
                    <button className={`${styles.actionButton} ${styles.deleteButton}`} title="Xóa"><FaTrash /></button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      
      {/* THÊM: Component Pagination */}
      <Pagination totalPages={totalPages} />
    </div>
  );
};
export default RoutesPage;