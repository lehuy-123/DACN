// app/admin/(dashboard)/routes/edit/[id]/page.tsx
"use client"; 
// SỬA: Thêm 'use' vào import
import React, { useState, useEffect, use } from 'react'; 
import Link from 'next/link';
import styles from '../../../../routes/form.module.css';

// --- Dữ liệu giả lập ---
const mockRoutes = [
    { id: 'ROUTE01', name: 'TP. HCM - Đà Lạt', start: 'Bến xe Miền Đông', end: 'Bến xe Liên tỉnh Đà Lạt', distance: '308 km', time: '8 giờ' },
    { id: 'ROUTE02', name: 'TP. HCM - Vũng Tàu', start: 'Bến xe Miền Đông', end: 'Bến xe Vũng Tàu', distance: '96 km', time: '2.5 giờ' },
];
// -----------------------

interface EditPageProps { 
  // SỬA: params giờ là một Promise
  params: Promise<{ id: string }>; 
}

export default function EditRoutePage({ params }: EditPageProps) {
  // SỬA: Dùng React.use() để đọc params
  const { id } = use(params); 
  
  const [formData, setFormData] = useState<any>(null);

  useEffect(() => {
    // TODO: Fetch dữ liệu thật
    const data = mockRoutes.find(p => p.id === id);
    if (data) setFormData(data);
  }, [id]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData((prev: any) => ({ ...prev, [name]: value }));
  };
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    alert('Đã cập nhật!');
  };

  if (!formData) {
    return <div className={styles.card}><div className={styles.header}><h1 className={styles.title}>Đang tải...</h1></div></div>;
  }

  return (
    <div className={styles.card}>
      <div className={styles.header}><h1 className={styles.title}>Chỉnh sửa: {formData.id}</h1></div>
      <form className={styles.form} onSubmit={handleSubmit}>
        <div className={styles.grid}>
          <div className={styles.formGroup}><label htmlFor="id" className={styles.label}>Mã tuyến</label><input type="text" id="id" name="id" className={styles.input} required value={formData.id} onChange={handleChange} /></div>
          <div className={styles.formGroup}><label htmlFor="name" className={styles.label}>Tên tuyến</label><input type="text" id="name" name="name" className={styles.input} required value={formData.name} onChange={handleChange} /></div>
          <div className={styles.formGroup}><label htmlFor="start" className={styles.label}>Điểm đi</label><input type="text" id="start" name="start" className={styles.input} required value={formData.start} onChange={handleChange} /></div>
          <div className={styles.formGroup}><label htmlFor="end" className={styles.label}>Điểm đến</label><input type="text" id="end" name="end" className={styles.input} required value={formData.end} onChange={handleChange} /></div>
          <div className={styles.formGroup}><label htmlFor="distance" className={styles.label}>Khoảng cách</label><input type="text" id="distance" name="distance" className={styles.input} value={formData.distance} onChange={handleChange} /></div>
          <div className={styles.formGroup}><label htmlFor="time" className={styles.label}>Thời gian ước tính</label><input type="text" id="time" name="time" className={styles.input} value={formData.time} onChange={handleChange} /></div>
          <div className={styles.actions}>
            <Link href="/admin/routes" className={`${styles.button} ${styles.cancelButton}`}>Hủy</Link>
            <button type="submit" className={`${styles.button} ${styles.saveButton}`}>Cập nhật</button>
          </div>
        </div>
      </form>
    </div>
  );
}