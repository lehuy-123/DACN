// app/admin/(dashboard)/schedules/new/page.tsx
"use client"; 
import React from 'react';
import Link from 'next/link';
import styles from '../../../schedules/form.module.css';

// --- (Giả lập) Dữ liệu từ Database ---
// TODO: Lấy dữ liệu này từ API
const routes = [
  { id: 'R001', name: 'TP. HCM - Đà Lạt' },
  { id: 'R002', name: 'Hà Nội - Hải Phòng' },
];
const vehicles = [
  { id: 'V001', licensePlate: '51F-123.45' },
  { id: 'V002', licensePlate: '29B-543.21' },
];
// Danh sách lịch trình ĐÃ TỒN TẠI (để kiểm tra trùng)
const existingSchedules = [
  { id: 'SG-DL-01', vehicleId: 'V001', startTime: '2025-10-28T22:00', endTime: '2025-10-29T06:00' },
  { id: 'HN-HP-05', vehicleId: 'V002', startTime: '2025-10-28T18:30', endTime: '2025-10-28T20:30' },
];
// ------------------------------------

/**
 * Hàm kiểm tra xem xe đã chọn có bị trùng lịch không
 * (Đây là logic validation cốt lõi)
 */
function isVehicleOverlapping(vehicleId: string, newStartTime: string, newEndTime: string) {
  const newStart = new Date(newStartTime).getTime();
  const newEnd = new Date(newEndTime).getTime();

  for (const schedule of existingSchedules) {
    if (schedule.vehicleId !== vehicleId) {
      continue; // Bỏ qua nếu không phải xe này
    }

    const existingStart = new Date(schedule.startTime).getTime();
    const existingEnd = new Date(schedule.endTime).getTime();

    // Logic kiểm tra trùng lặp thời gian
    // (A < B) và (B > A)
    if (newStart < existingEnd && newEnd > existingStart) {
      return true; // Bị trùng
    }
  }
  return false; // Không trùng
}


export default function CreateSchedulePage() {
  
  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    
    // Lấy dữ liệu từ form
    const formData = new FormData(e.currentTarget);
    const data = Object.fromEntries(formData.entries());
    
    // === BẮT ĐẦU VALIDATION ===
    const vehicleId = data.vehicle as string;
    const startTime = data.startTime as string;
    const endTime = data.endTime as string;

    if (isVehicleOverlapping(vehicleId, startTime, endTime)) {
      alert(`LỖI: Xe ${vehicleId} đã có lịch trình khác trong khoảng thời gian này. Vui lòng chọn xe khác hoặc đổi giờ.`);
      return; // Dừng, không cho submit
    }
    // === KẾT THÚC VALIDATION ===

    alert('Đã tạo lịch trình mới thành công! (Không bị trùng)');
  };

  return (
    <div className={styles.card}>
      <div className={styles.header}><h1 className={styles.title}>Thêm lịch trình mới</h1></div>
      <form className={styles.form} onSubmit={handleSubmit}>
        <div className={styles.grid}>
          <div className={styles.formGroup}><label htmlFor="id" className={styles.label}>Mã chuyến</label><input type="text" id="id" name="id" className={styles.input} placeholder="Ví dụ: SG-DL-02" required /></div>
          <div className={styles.formGroup}><label htmlFor="route" className={styles.label}>Chọn Tuyến xe</label><select id="route" name="route" className={styles.select}>{routes.map(r => (<option key={r.id} value={r.id}>{r.name}</option>))}</select></div>
          <div className={styles.formGroup}><label htmlFor="vehicle" className={styles.label}>Chọn Xe</label><select id="vehicle" name="vehicle" className={styles.select}>{vehicles.map(v => (<option key={v.id} value={v.id}>{v.licensePlate}</option>))}</select></div>
          <div className={styles.formGroup}><label htmlFor="seats" className={styles.label}>Tổng số ghế</label><input type="number" id="seats" name="seats" className={styles.input} defaultValue={40} required /></div>
          <div className={styles.formGroup}><label htmlFor="startTime" className={styles.label}>Giờ khởi hành</label><input type="datetime-local" id="startTime" name="startTime" className={styles.input} required /></div>
          <div className={styles.formGroup}><label htmlFor="endTime" className={styles.label}>Giờ dự kiến đến</label><input type="datetime-local" id="endTime" name="endTime" className={styles.input} required /></div>
          <div className={styles.actions}>
            <Link href="/admin/schedules" className={`${styles.button} ${styles.cancelButton}`}>Hủy</Link>
            <button type="submit" className={`${styles.button} ${styles.saveButton}`}>Lưu lịch trình</button>
          </div>
        </div>
      </form>
    </div>
  );
}