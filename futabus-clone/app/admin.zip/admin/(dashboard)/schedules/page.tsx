// app/admin/(dashboard)/schedules/page.tsx
import React from 'react';
import Link from 'next/link';
import styles from '../../schedules/schedules.module.css';
import { FaEdit, FaTrash, FaEye, FaPlus } from 'react-icons/fa';

// SỬA: Lùi 2 cấp (../../) thay vì 3
import Search from '../../_components/Search';
import Pagination from '../../_components/Pagination';

// Số lượng mục trên mỗi trang
const ITEMS_PER_PAGE = 5;

// Dữ liệu giả
const mockSchedules = [
  { id: 'SG-DL-01', route: 'TP. HCM - Đà Lạt', startTime: '2025-10-28 22:00' },
  { id: 'HN-HP-05', route: 'Hà Nội - Hải Phòng', startTime: '2025-10-28 18:30' },
  { id: 'DN-HUE-02', route: 'Đà Nẵng - Huế', startTime: '2025-10-27 08:00' },
  { id: 'SG-VT-09', route: 'TP. HCM - Vũng Tàu', startTime: '2025-10-29 09:00' },
  { id: 'SG-DL-02', route: 'TP. HCM - Đà Lạt', startTime: '2025-10-29 23:00' },
  { id: 'HN-HP-06', route: 'Hà Nội - Hải Phòng', startTime: '2025-10-29 19:30' },
  { id: 'DN-HUE-03', route: 'Đà Nẵng - Huế', startTime: '2025-10-28 09:00' },
];

async function getSchedules(query: string, currentPage: number) {
  const filteredSchedules = mockSchedules.filter((schedule) =>
    schedule.id.toLowerCase().includes(query.toLowerCase()) ||
    schedule.route.toLowerCase().includes(query.toLowerCase())
  );

  const totalPages = Math.ceil(filteredSchedules.length / ITEMS_PER_PAGE);
  const offset = (currentPage - 1) * ITEMS_PER_PAGE;
  const schedules = filteredSchedules.slice(offset, offset + ITEMS_PER_PAGE);

  return { schedules, totalPages };
}

// SỬA: Thêm 'await' cho searchParams
const SchedulesPage = async ({
  searchParams,
}: {
  searchParams?: Promise<{
    query?: string;
    page?: string;
  }>;
}) => {
  const awaitedParams = await searchParams; // Phải await
  const query = awaitedParams?.query || '';
  const currentPage = Number(awaitedParams?.page) || 1;

  const { schedules, totalPages } = await getSchedules(query, currentPage);

  return (
    <div className={styles.container}>
      <div className={styles.header}>
        <h1 className={styles.title}>Quản lý Lịch trình</h1>
        <Link href="/admin/schedules/new" className={styles.addButton} title="Thêm lịch trình mới">
          <FaPlus />
        </Link>
      </div>
      
      <div className={styles.toolbar}>
        <Search placeholder="Tìm kiếm (mã chuyến, tuyến...)" />
      </div>

      <div className={styles.tableWrapper}>
        <table className={styles.table}>
          <thead>
            <tr>
              <th>Mã chuyến</th>
              <th>Tuyến xe</th>
              <th>Giờ khởi hành</th>
              <th>Hành động</th>
            </tr>
          </thead>
          <tbody>
            {schedules.map((schedule) => (
              <tr key={schedule.id}>
                <td>{schedule.id}</td>
                <td>{schedule.route}</td>
                <td>{schedule.startTime}</td>
                <td>
                  <div className={styles.actions}>
                    <Link href={`/admin/schedules/${schedule.id}`} className={`${styles.actionButton} ${styles.viewButton}`} title="Xem chi tiết"><FaEye /></Link>
                    <Link href={`/admin/schedules/edit/${schedule.id}`} className={`${styles.actionButton} ${styles.editButton}`} title="Chỉnh sửa"><FaEdit /></Link>
                    <button className={`${styles.actionButton} ${styles.deleteButton}`} title="Xóa"><FaTrash /></button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      
      <Pagination totalPages={totalPages} />
    </div>
  );
};

export default SchedulesPage;