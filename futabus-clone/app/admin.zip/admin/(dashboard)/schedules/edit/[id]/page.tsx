// app/admin/(dashboard)/schedules/edit/[id]/page.tsx
"use client"; 
import React, { useState, useEffect, use } from 'react';
import Link from 'next/link';
import styles from '../../../../schedules/form.module.css';

// --- (Giả lập) Dữ liệu từ Database ---
const routes = [ { id: 'R001', name: 'TP. HCM - Đà Lạt' }, { id: 'R002', name: 'Hà Nội - Hải Phòng' }];
const vehicles = [ { id: 'V001', licensePlate: '51F-123.45' }, { id: 'V002', licensePlate: '29B-543.21' }];
const existingSchedules = [
  { id: 'SG-DL-01', vehicleId: 'V001', startTime: '2025-10-28T22:00', endTime: '2025-10-29T06:00' },
  { id: 'HN-HP-05', vehicleId: 'V002', startTime: '2025-10-28T18:30', endTime: '2025-10-28T20:30' },
];
// ------------------------------------

/**
 * Hàm kiểm tra trùng lặp, BỎ QUA lịch trình hiện tại
 */
function isVehicleOverlapping(vehicleId: string, newStartTime: string, newEndTime: string, currentScheduleId: string) {
  const newStart = new Date(newStartTime).getTime();
  const newEnd = new Date(newEndTime).getTime();

  for (const schedule of existingSchedules) {
    // SỬA: Bỏ qua chính nó khi kiểm tra
    if (schedule.id === currentScheduleId) {
      continue; 
    }
    if (schedule.vehicleId !== vehicleId) {
      continue;
    }
    const existingStart = new Date(schedule.startTime).getTime();
    const existingEnd = new Date(schedule.endTime).getTime();

    if (newStart < existingEnd && newEnd > existingStart) {
      return true; // Bị trùng
    }
  }
  return false; // Không trùng
}

interface EditPageProps { params: Promise<{ id: string }>; }

export default function EditSchedulePage({ params }: EditPageProps) {
  const { id } = use(params); 
  const [formData, setFormData] = useState<any>(null);

  useEffect(() => {
    // TODO: Fetch dữ liệu thật
    const data = existingSchedules.find(s => s.id === id);
    if (data) setFormData(data);
  }, [id]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData((prev: any) => ({ ...prev, [name]: value }));
  };
  
  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    
    // === BẮT ĐẦU VALIDATION ===
    const vehicleId = formData.vehicleId as string;
    const startTime = formData.startTime as string;
    const endTime = formData.endTime as string;

    if (isVehicleOverlapping(vehicleId, startTime, endTime, id)) {
      alert(`LỖI: Xe ${vehicleId} đã có lịch trình khác trong khoảng thời gian này.`);
      return; 
    }
    // === KẾT THÚC VALIDATION ===

    alert('Đã cập nhật thành công! (Không bị trùng)');
  };

  if (!formData) {
    return <div className={styles.card}><div className={styles.header}><h1 className={styles.title}>Đang tải...</h1></div></div>;
  }

  return (
    <div className={styles.card}>
      <div className={styles.header}><h1 className={styles.title}>Chỉnh sửa: {formData.id}</h1></div>
      <form className={styles.form} onSubmit={handleSubmit}>
        <div className={styles.grid}>
          <div className={styles.formGroup}><label htmlFor="id" className={styles.label}>Mã chuyến</label><input type="text" id="id" name="id" className={styles.input} required value={formData.id} readOnly /></div>
          <div className={styles.formGroup}><label htmlFor="route" className={styles.label}>Chọn Tuyến xe</label><select id="route" name="routeId" className={styles.select} value={formData.routeId} onChange={handleChange}>{routes.map(r => (<option key={r.id} value={r.id}>{r.name}</option>))}</select></div>
          <div className={styles.formGroup}><label htmlFor="vehicle" className={styles.label}>Chọn Xe</label><select id="vehicle" name="vehicleId" className={styles.select} value={formData.vehicleId} onChange={handleChange}>{vehicles.map(v => (<option key={v.id} value={v.id}>{v.licensePlate}</option>))}</select></div>
          <div className={styles.formGroup}><label htmlFor="startTime" className={styles.label}>Giờ khởi hành</label><input type="datetime-local" id="startTime" name="startTime" className={styles.input} required value={formData.startTime} onChange={handleChange} /></div>
          <div className={styles.formGroup}><label htmlFor="endTime" className={styles.label}>Giờ dự kiến đến</label><input type="datetime-local" id="endTime" name="endTime" className={styles.input} required value={formData.endTime} onChange={handleChange} /></div>
          <div className={styles.actions}>
            <Link href="/admin/schedules" className={`${styles.button} ${styles.cancelButton}`}>Hủy</Link>
            <button type="submit" className={`${styles.button} ${styles.saveButton}`}>Cập nhật</button>
          </div>
        </div>
      </form>
    </div>
  );
}