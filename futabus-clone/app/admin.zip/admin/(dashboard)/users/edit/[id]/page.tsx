// app/admin/(dashboard)/users/edit/[id]/page.tsx
"use client"; 
import React, { useState, useEffect, use } from 'react';
import Link from 'next/link';
import styles from '../../../../users/form.module.css';

const mockUsers = [
    { id: '1', name: 'Nguyễn Văn A', email: 'nguyenvana@email.com', role: 'Admin', joinDate: '2023-10-01' },
    { id: '2', name: 'Trần Thị B', email: 'tranthib@email.com', role: 'User', joinDate: '2023-10-05' },
];

interface EditPageProps { params: Promise<{ id: string }>; }

export default function EditUserPage({ params }: EditPageProps) {
  const { id } = use(params); // Sửa lỗi 'await params'
  const [formData, setFormData] = useState<any>(null);

  useEffect(() => {
    // TODO: Fetch dữ liệu thật
    const data = mockUsers.find(p => p.id === id);
    if (data) setFormData(data);
  }, [id]);

  const handleChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData((prev: any) => ({ ...prev, [name]: value }));
  };
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    alert('Đã cập nhật vai trò!');
  };

  if (!formData) {
    return <div className={styles.card}><div className={styles.header}><h1 className={styles.title}>Đang tải...</h1></div></div>;
  }

  return (
    <div className={styles.card}>
      <div className={styles.header}><h1 className={styles.title}>Chỉnh sửa: {formData.name}</h1></div>
      <form className={styles.form} onSubmit={handleSubmit}>
        <div className={styles.grid}>
          <div className={styles.formGroup}><label className={styles.label}>Email</label><input type="email" className={styles.input} value={formData.email} disabled /></div>
          <div className={styles.formGroup}><label htmlFor="role" className={styles.label}>Vai trò</label><select id="role" name="role" className={styles.select} value={formData.role} onChange={handleChange}><option value="User">User</option><option value="Editor">Editor</option><option value="Admin">Admin</option></select></div>
          <div className={styles.actions}>
            <Link href="/admin/users" className={`${styles.button} ${styles.cancelButton}`}>Hủy</Link>
            <button type="submit" className={`${styles.button} ${styles.saveButton}`}>Cập nhật</button>
          </div>
        </div>
      </form>
    </div>
  );
}