// app/admin/(dashboard)/users/new/page.tsx
"use client"; 
import React from 'react';
import Link from 'next/link';
// Sửa: Đường dẫn import CSS lùi 3 cấp
import styles from '../../../users/form.module.css';

export default function CreateUserPage() {
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    alert('Đã thêm người dùng mới!');
  };

  return (
    <div className={styles.card}>
      <div className={styles.header}>
        <h1 className={styles.title}>Thêm người dùng mới</h1>
      </div>
      
      <form className={styles.form} onSubmit={handleSubmit}>
        <div className={styles.grid}>
          
          <div className={styles.formGroup}>
            <label htmlFor="name" className={styles.label}>Họ và Tên</label>
            <input type="text" id="name" name="name" className={styles.input} required />
          </div>
          
          <div className={styles.formGroup}>
            <label htmlFor="email" className={styles.label}>Email</label>
            <input type="email" id="email" name="email" className={styles.input} required />
          </div>

          <div className={styles.formGroup}>
            <label htmlFor="password" className={styles.label}>Mật khẩu</label>
            <input type="password" id="password" name="password" className={styles.input} required />
          </div>

          <div className={styles.formGroup}>
            <label htmlFor="role" className={styles.label}>Vai trò</label>
            <select id="role" name="role" className={styles.select}>
              <option value="User">User</option>
              <option value="Editor">Editor</option>
              <option value="Admin">Admin</option>
            </select>
          </div>
          
          <div className={styles.actions}>
            <Link href="/admin/users" className={`${styles.button} ${styles.cancelButton}`}>
              Hủy
            </Link>
            <button type="submit" className={`${styles.button} ${styles.saveButton}`}>
              Lưu
            </button>
          </div>
          
        </div>
      </form>
    </div>
  );
}