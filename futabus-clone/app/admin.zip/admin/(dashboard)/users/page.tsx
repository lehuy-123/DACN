// app/admin/(dashboard)/users/page.tsx
import React from 'react';
import Link from 'next/link';
import styles from '../../users/users.module.css'; 
import { FaEdit, FaTrash, FaEye, FaPlus } from 'react-icons/fa'; 

// Import đúng (không có dấu {})
import Search from '../../_components/Search';
import Pagination from '../../_components/Pagination';

const ITEMS_PER_PAGE = 5;

// Dữ liệu giả
const mockUsers = [
  { id: '1', name: 'Nguyễn Văn A', email: 'nguyenvana@email.com', role: 'Admin', joinDate: '2023-10-01' },
  { id: '2', name: 'Trần Thị B', email: 'tranthib@email.com', role: 'User', joinDate: '2023-10-05' },
  { id: '3', name: 'Lê Văn C', email: 'levanc@email.com', role: 'User', joinDate: '2023-10-12' },
  { id: '4', name: 'Phạm Thị D', email: 'phamthid@email.com', role: 'Editor', joinDate: '2023-11-20' },
  { id: '5', name: 'Hoàng Văn E', email: 'hoangvane@email.com', role: 'User', joinDate: '2023-11-25' },
  { id: '6', name: 'Đỗ Thị F', email: 'dothif@email.com', role: 'User', joinDate: '2023-12-01' },
];

async function getUsers(query: string, currentPage: number) {
  const filteredUsers = mockUsers.filter((user) =>
    user.name.toLowerCase().includes(query.toLowerCase()) ||
    user.email.toLowerCase().includes(query.toLowerCase())
  );

  const totalPages = Math.ceil(filteredUsers.length / ITEMS_PER_PAGE);
  const offset = (currentPage - 1) * ITEMS_PER_PAGE;
  const users = filteredUsers.slice(offset, offset + ITEMS_PER_PAGE);

  return { users, totalPages };
}

// SỬA: Thêm props searchParams và 'await'
const UsersPage = async ({
  searchParams,
}: {
  searchParams?: Promise<{ // SỬA: Bọc trong Promise
    query?: string;
    page?: string;
  }>;
}) => {
  // SỬA: Phải 'await' để lấy giá trị
  const awaitedParams = await searchParams; 
  const query = awaitedParams?.query || '';
  const currentPage = Number(awaitedParams?.page) || 1;

  const { users, totalPages } = await getUsers(query, currentPage);

  return (
    <div className={styles.container}>
      <div className={styles.header}>
        <h1 className={styles.title}>Quản lý người dùng</h1>
        <Link href="/admin/users/new" className={styles.addButton} title="Thêm người dùng mới">
          <FaPlus />
        </Link>
      </div>
      
      <div className={styles.toolbar}>
        <Search placeholder="Tìm kiếm (tên, email...)" />
      </div>

      <div className={styles.tableWrapper}>
        <table className={styles.table}>
          <thead>
            <tr>
              <th>Họ và Tên</th>
              <th>Email</th>
              <th>Hành động</th>
            </tr>
          </thead>
          <tbody>
            {users.map((user) => (
              <tr key={user.id}>
                <td>{user.name}</td>
                <td>{user.email}</td>
                <td>
                  <div className={styles.actions}>
                    <Link href={`/admin/users/${user.id}`} className={`${styles.actionButton} ${styles.viewButton}`} title="Xem chi tiết"><FaEye /></Link>
                    <Link href={`/admin/users/edit/${user.id}`} className={`${styles.actionButton} ${styles.editButton}`} title="Chỉnh sửa vai trò"><FaEdit /></Link>
                    <button className={`${styles.actionButton} ${styles.deleteButton}`} title="Xóa"><FaTrash /></button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      
      <Pagination totalPages={totalPages} />
    </div>
  );
};
export default UsersPage;