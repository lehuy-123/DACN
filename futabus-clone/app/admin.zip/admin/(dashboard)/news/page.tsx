// app/admin/(dashboard)/news/page.tsx
import React from 'react';
import Link from 'next/link';
import styles from '../../news/news.module.css'; 
import { FaEdit, FaTrash, FaSearch, FaEye, FaPlus } from 'react-icons/fa'; 

// SỬA: Xóa dấu {} khỏi 2 dòng import này
import Search from '../../_components/Search';
import Pagination from '../../_components/Pagination';

const ITEMS_PER_PAGE = 5;

// Dữ liệu giả
const mockNews = [
  { id: 'NEWS001', title: 'FUTA Bus Lines mở tuyến mới TPHCM - Cà Mau', author: 'Admin', date: '2025-10-15', status: 'Đã xuất bản' },
  { id: 'NEWS002', title: 'Chương trình khuyến mãi đặc biệt dịp lễ 30/4', author: 'Marketing Team', date: '2025-04-20', status: 'Đã xuất bản' },
  { id: 'NEWS003', title: 'Hướng dẫn đặt vé trực tuyến an toàn', author: 'Admin', date: '2025-03-10', status: 'Đã xuất bản' },
  { id: 'NEWS004', title: 'Nâng cấp đội xe Limousine cho tuyến Sài Gòn - Vũng Tàu', author: 'Admin', date: '2025-02-28', status: 'Bản nháp' },
  { id: 'NEWS005', title: 'Tuyển dụng tài xế tháng 11', author: 'HR', date: '2025-10-30', status: 'Bản nháp' },
  { id: 'NEWS006', title: 'Chào mừng ngày nhà giáo Việt Nam 20/11', author: 'Marketing Team', date: '2025-11-01', status: 'Đã xuất bản' },
];

async function getNews(query: string, currentPage: number) {
  const filteredNews = mockNews.filter((news) =>
    news.title.toLowerCase().includes(query.toLowerCase()) ||
    news.author.toLowerCase().includes(query.toLowerCase())
  );

  const totalPages = Math.ceil(filteredNews.length / ITEMS_PER_PAGE);
  const offset = (currentPage - 1) * ITEMS_PER_PAGE;
  const newsList = filteredNews.slice(offset, offset + ITEMS_PER_PAGE);

  return { newsList, totalPages };
}

// SỬA: Thêm props searchParams và 'await'
const NewsPage = async ({
  searchParams, 
}: {
  searchParams?: Promise<{ // Bọc trong Promise
    query?: string;
    page?: string;
  }>;
}) => {
  // Phải 'await' để lấy giá trị
  const awaitedParams = await searchParams; 
  const query = awaitedParams?.query || '';
  const currentPage = Number(awaitedParams?.page) || 1;

  const { newsList, totalPages } = await getNews(query, currentPage);

  return (
    <div className={styles.container}>
      <div className={styles.header}>
        <h1 className={styles.title}>Quản lý Tin tức</h1>
        <Link href="/admin/news/new" className={styles.addButton} title="Thêm bài viết mới">
          <FaPlus />
        </Link>
      </div>
      
      <div className={styles.toolbar}>
        <Search placeholder="Tìm kiếm (tiêu đề, tác giả...)" />
      </div>

      <div className={styles.tableWrapper}>
        <table className={styles.table}>
          <thead>
            <tr>
              <th>Mã tin</th>
              <th>Ngày đăng</th>
              <th>Hành động</th>
            </tr>
          </thead>
          <tbody>
            {newsList.map((news) => (
              <tr key={news.id}>
                <td>{news.id}</td>
                <td>{news.date}</td>
                <td>
                  <div className={styles.actions}>
                    <Link href={`/admin/news/${news.id}`} className={`${styles.actionButton} ${styles.viewButton}`} title="Xem chi tiết"><FaEye /></Link>
                    <Link href={`/admin/news/edit/${news.id}`} className={`${styles.actionButton} ${styles.editButton}`} title="Chỉnh sửa"><FaEdit /></Link>
                    <button className={`${styles.actionButton} ${styles.deleteButton}`} title="Xóa"><FaTrash /></button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      
      <Pagination totalPages={totalPages} />
    </div>
  );
};
export default NewsPage;