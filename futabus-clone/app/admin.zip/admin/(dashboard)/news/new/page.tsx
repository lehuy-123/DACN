// app/admin/(dashboard)/news/new/page.tsx
"use client"; 
import React from 'react';
import Link from 'next/link';
import styles from '../../../news/form.module.css';

export default function CreateNewsPage() {
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    alert('Đã đăng bài viết mới!');
  };

  return (
    <div className={styles.card}>
      <div className={styles.header}><h1 className={styles.title}>Thêm bài viết mới</h1></div>
      <form className={styles.form} onSubmit={handleSubmit}>
        <div className={styles.grid}>
          <div className={styles.formGroupFull}>
            <label htmlFor="title" className={styles.label}>Tiêu đề bài viết</label>
            <input type="text" id="title" name="title" className={styles.input} required />
          </div>
          <div className={styles.formGroup}>
            <label htmlFor="author" className={styles.label}>Tác giả</label>
            <input type="text" id="author" name="author" className={styles.input} defaultValue="Admin" required />
          </div>
          <div className={styles.formGroup}>
            <label htmlFor="status" className={styles.label}>Trạng thái</label>
            <select id="status" name="status" className={styles.select}>
              <option value="Đã xuất bản">Đã xuất bản</option>
              <option value="Bản nháp">Bản nháp</option>
            </select>
          </div>
          <div className={styles.formGroupFull}>
            <label htmlFor="content" className={styles.label}>Nội dung</label>
            <textarea id="content" name="content" className={styles.textarea} placeholder="Viết nội dung bài viết ở đây..." />
          </div>
          <div className={styles.actions}>
            <Link href="/admin/news" className={`${styles.button} ${styles.cancelButton}`}>Hủy</Link>
            <button type="submit" className={`${styles.button} ${styles.saveButton}`}>Đăng bài</button>
          </div>
        </div>
      </form>
    </div>
  );
}