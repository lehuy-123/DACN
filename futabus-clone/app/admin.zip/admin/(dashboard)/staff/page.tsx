// app/admin/(dashboard)/staff/page.tsx
import React from 'react';
import Link from 'next/link';
import styles from '../../staff/staff.module.css'; 
import { FaEdit, FaTrash, FaSearch, FaEye, FaPlus } from 'react-icons/fa';
// THÊM: Import Search và Pagination
import Search from '../../_components/Search';
import Pagination from '../../_components/Pagination';

const ITEMS_PER_PAGE = 5;

// Dữ liệu giả
const mockStaff = [
  { id: 'NV001', name: 'Nguyễn Văn An', role: 'Tài xế' },
  { id: 'NV002', name: 'Trần Thị Bình', role: 'Phụ xe' },
  { id: 'NV003', name: 'Lê Văn Cường', role: 'Tài xế' },
  { id: 'NV004', name: 'Phạm Thị Dung', role: 'Tài xế' },
  { id: 'NV005', name: 'Lý Thị Huệ', role: 'Nhân viên VP' },
  { id: 'NV006', name: 'Hoàng Văn F', role: 'Tài xế' },
];

// SỬA: Hàm lấy dữ liệu
async function getStaff(query: string, currentPage: number) {
  const filteredStaff = mockStaff.filter((staff) =>
    staff.name.toLowerCase().includes(query.toLowerCase()) ||
    staff.role.toLowerCase().includes(query.toLowerCase())
  );

  const totalPages = Math.ceil(filteredStaff.length / ITEMS_PER_PAGE);
  const offset = (currentPage - 1) * ITEMS_PER_PAGE;
  const staffList = filteredStaff.slice(offset, offset + ITEMS_PER_PAGE);

  return { staffList, totalPages };
}

// SỬA: Thêm props searchParams và 'await'
const StaffPage = async ({
  searchParams,
}: {
  searchParams?: Promise<{
    query?: string;
    page?: string;
  }>;
}) => {
  const awaitedParams = await searchParams; 
  const query = awaitedParams?.query || '';
  const currentPage = Number(awaitedParams?.page) || 1;

  const { staffList, totalPages } = await getStaff(query, currentPage);

  return (
    <div className={styles.container}>
      <div className={styles.header}>
        <h1 className={styles.title}>Quản lý Nhân viên</h1>
        <Link href="/admin/staff/new" className={styles.addButton} title="Thêm nhân viên mới">
          <FaPlus />
        </Link>
      </div>
      
      {/* THÊM: Component Search */}
      <div className={styles.toolbar}>
        <Search placeholder="Tìm kiếm (tên, SĐT, biển số...)" />
      </div>

      <div className={styles.tableWrapper}>
        <table className={styles.table}>
          <thead>
            <tr>
              <th>Mã NV</th>
              <th>Họ và Tên</th>
              <th>Chức vụ</th>
              <th>Hành động</th>
            </tr>
          </thead>
          <tbody>
            {/* SỬA: map từ staffList */}
            {staffList.map((staff) => (
              <tr key={staff.id}>
                <td>{staff.id}</td>
                <td>{staff.name}</td>
                <td>{staff.role}</td>
                <td>
                  <div className={styles.actions}>
                    <Link href={`/admin/staff/${staff.id}`} className={`${styles.actionButton} ${styles.viewButton}`} title="Xem chi tiết"><FaEye /></Link>
                    <Link href={`/admin/staff/edit/${staff.id}`} className={`${styles.actionButton} ${styles.editButton}`} title="Chỉnh sửa"><FaEdit /></Link>
                    <button className={`${styles.actionButton} ${styles.deleteButton}`} title="Xóa"><FaTrash /></button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      
      {/* THÊM: Component Pagination */}
      <Pagination totalPages={totalPages} />
    </div>
  );
};
export default StaffPage;