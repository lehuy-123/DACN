// app/admin/(dashboard)/staff/new/page.tsx
"use client"; 
import React from 'react';
import Link from 'next/link';
import styles from '../../../staff/form.module.css';

export default function CreateStaffPage() {
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    alert('Đã thêm nhân viên mới!');
  };

  return (
    <div className={styles.card}>
      <div className={styles.header}><h1 className={styles.title}>Thêm nhân viên mới</h1></div>
      <form className={styles.form} onSubmit={handleSubmit}>
        <div className={styles.grid}>
          <div className={styles.formGroup}><label htmlFor="id" className={styles.label}>Mã NV</label><input type="text" id="id" name="id" className={styles.input} placeholder="Ví dụ: NV005" required /></div>
          <div className={styles.formGroup}><label htmlFor="name" className={styles.label}>Họ và Tên</label><input type="text" id="name" name="name" className={styles.input} required /></div>
          <div className={styles.formGroup}><label htmlFor="phone" className={styles.label}>Số điện thoại</label><input type="tel" id="phone" name="phone" className={styles.input} required /></div>
          <div className={styles.formGroup}><label htmlFor="role" className={styles.label}>Chức vụ</label><select id="role" name="role" className={styles.select}><option value="Tài xế">Tài xế</option><option value="Phụ xe">Phụ xe</option><option value="Nhân viên VP">Nhân viên VP</option></select></div>
          <div className={styles.formGroup}><label htmlFor="license" className={styles.label}>Số GPLX (Nếu có)</label><input type="text" id="license" name="license" className={styles.input} /></div>
          <div className={styles.formGroup}><label htmlFor="status" className={styles.label}>Trạng thái</label><select id="status" name="status" className={styles.select}><option value="Đang làm việc">Đang làm việc</option><option value="Tạm nghỉ">Tạm nghỉ</option></select></div>
          <div className={styles.actions}>
            <Link href="/admin/staff" className={`${styles.button} ${styles.cancelButton}`}>Hủy</Link>
            <button type="submit" className={`${styles.button} ${styles.saveButton}`}>Lưu nhân viên</button>
          </div>
        </div>
      </form>
    </div>
  );
}