// app/admin/(dashboard)/staff/edit/[id]/page.tsx
"use client"; 
import React, { useState, useEffect, use } from 'react';
import Link from 'next/link';
import styles from '../../../../staff/form.module.css';

const mockStaff = [
    { id: 'NV001', name: 'Nguyễn Văn An', phone: '0901234567', role: 'Tài xế', license: 'B2-123456', status: 'Đang làm việc' },
];

interface EditPageProps { params: Promise<{ id: string }>; }

export default function EditStaffPage({ params }: EditPageProps) {
  const { id } = use(params); // Sửa lỗi 'await params'
  const [formData, setFormData] = useState<any>(null);

  useEffect(() => {
    // TODO: Fetch dữ liệu thật
    if (id === 'NV001') setFormData(mockStaff[0]);
  }, [id]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData((prev: any) => ({ ...prev, [name]: value }));
  };
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    alert('Đã cập nhật!');
  };

  if (!formData) {
    return <div className={styles.card}><div className={styles.header}><h1 className={styles.title}>Đang tải...</h1></div></div>;
  }

  return (
    <div className={styles.card}>
      <div className={styles.header}><h1 className={styles.title}>Chỉnh sửa: {formData.name}</h1></div>
      <form className={styles.form} onSubmit={handleSubmit}>
        <div className={styles.grid}>
          <div className={styles.formGroup}><label htmlFor="id" className={styles.label}>Mã NV</label><input type="text" id="id" name="id" className={styles.input} required value={formData.id} onChange={handleChange} /></div>
          <div className={styles.formGroup}><label htmlFor="name" className={styles.label}>Họ và Tên</label><input type="text" id="name" name="name" className={styles.input} required value={formData.name} onChange={handleChange} /></div>
          <div className={styles.formGroup}><label htmlFor="phone" className={styles.label}>Số điện thoại</label><input type="tel" id="phone" name="phone" className={styles.input} required value={formData.phone} onChange={handleChange} /></div>
          <div className={styles.formGroup}><label htmlFor="role" className={styles.label}>Chức vụ</label><select id="role" name="role" className={styles.select} value={formData.role} onChange={handleChange}><option value="Tài xế">Tài xế</option><option value="Phụ xe">Phụ xe</option><option value="Nhân viên VP">Nhân viên VP</option></select></div>
          <div className={styles.formGroup}><label htmlFor="license" className={styles.label}>Số GPLX (Nếu có)</label><input type="text" id="license" name="license" className={styles.input} value={formData.license} onChange={handleChange} /></div>
          <div className={styles.formGroup}><label htmlFor="status" className={styles.label}>Trạng thái</label><select id="status" name="status" className={styles.select} value={formData.status} onChange={handleChange}><option value="Đang làm việc">Đang làm việc</option><option value="Tạm nghỉ">Tạm nghỉ</option></select></div>
          <div className={styles.actions}>
            <Link href="/admin/staff" className={`${styles.button} ${styles.cancelButton}`}>Hủy</Link>
            <button type="submit" className={`${styles.button} ${styles.saveButton}`}>Cập nhật</button>
          </div>
        </div>
      </form>
    </div>
  );
}