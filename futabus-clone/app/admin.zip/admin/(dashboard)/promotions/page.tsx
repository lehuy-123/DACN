// app/admin/(dashboard)/promotions/page.tsx
import React from 'react';
import Link from 'next/link';
import styles from '../../promotions/promotions.module.css'; 
import { FaEdit, FaTrash, FaEye, FaPlus } from 'react-icons/fa'; 

// SỬA: Import không có {}
import Search from '../../_components/Search';
import Pagination from '../../_components/Pagination';

const ITEMS_PER_PAGE = 5;

// Dữ liệu giả
const mockPromotions = [
  { id: 'KM001', code: 'FUTA10', description: 'Giảm 10%...', startDate: '2025-10-01', endDate: '2025-10-31' },
  { id: 'KM002', code: 'CHAOMUNG', description: 'Giảm 20,000đ...', startDate: '2025-09-15', endDate: '2025-12-31' },
  { id: 'KM003', code: 'SINHNHAT', description: 'Giảm 50,000đ...', startDate: '2025-01-01', endDate: '2025-12-31' },
  { id: 'KM004', code: 'HE2025', description: 'Giảm giá vé hè', startDate: '2025-06-01', endDate: '2025-08-31' },
  { id: 'KM005', code: 'FUTAVIP', description: 'Giảm 20% cho KH VIP', startDate: '2025-01-01', endDate: '2025-12-31' },
  { id: 'KM006', code: 'DIHOC', description: 'Giảm giá sinh viên', startDate: '2025-09-01', endDate: '2025-09-30' },
];

async function getPromotions(query: string, currentPage: number) {
  const filteredPromotions = mockPromotions.filter((promo) =>
    promo.code.toLowerCase().includes(query.toLowerCase()) ||
    promo.description.toLowerCase().includes(query.toLowerCase())
  );

  const totalPages = Math.ceil(filteredPromotions.length / ITEMS_PER_PAGE);
  const offset = (currentPage - 1) * ITEMS_PER_PAGE;
  const promotions = filteredPromotions.slice(offset, offset + ITEMS_PER_PAGE);

  return { promotions, totalPages };
}

// SỬA: Thêm props searchParams và 'await'
const PromotionsPage = async ({
  searchParams,
}: {
  searchParams?: Promise<{ // SỬA: Bọc trong Promise
    query?: string;
    page?: string;
  }>;
}) => {
  // SỬA: Phải 'await' để lấy giá trị
  const awaitedParams = await searchParams; 
  const query = awaitedParams?.query || '';
  const currentPage = Number(awaitedParams?.page) || 1;

  const { promotions, totalPages } = await getPromotions(query, currentPage);

  return (
    <div className={styles.container}>
      <div className={styles.header}>
        <h1 className={styles.title}>Quản lý Khuyến mãi</h1>
        <Link href="/admin/promotions/new" className={styles.addButton} title="Tạo Khuyến mãi mới">
          <FaPlus />
        </Link>
      </div>

      <div className={styles.toolbar}>
        <Search placeholder="Tìm kiếm (mã, mô tả...)" />
      </div>

      <div className={styles.tableWrapper}>
        <table className={styles.table}>
          <thead>
            <tr>
              <th>Mã Code</th>
              <th>Ngày bắt đầu</th>
              <th>Ngày kết thúc</th>
              <th>Hành động</th>
            </tr>
          </thead>
          <tbody>
            {promotions.map((promo) => (
              <tr key={promo.id}>
                <td className={styles.promoCode}>{promo.code}</td>
                <td>{promo.startDate}</td>
                <td>{promo.endDate}</td>
                <td>
                  <div className={styles.actions}>
                    <Link href={`/admin/promotions/${promo.id}`} className={`${styles.actionButton} ${styles.viewButton}`} title="Xem chi tiết"><FaEye /></Link>
                    <Link href={`/admin/promotions/edit/${promo.id}`} className={`${styles.actionButton} ${styles.editButton}`} title="Chỉnh sửa"><FaEdit /></Link>
                    <button className={`${styles.actionButton} ${styles.deleteButton}`} title="Xóa"><FaTrash /></button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      
      <Pagination totalPages={totalPages} />
    </div>
  );
};
export default PromotionsPage;