// app/admin/(dashboard)/promotions/edit/[id]/page.tsx
"use client"; // Form cần 'use client' để xử lý state

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
// DÙNG CHUNG CSS với form "Tạo mới" (lùi ra 4 cấp)
import styles from '../../../../promotions/form.module.css';

// --- Dữ liệu giả lập để fetch ---
const mockPromotions = [
    { id: 'KM001', code: 'FUTA10', description: 'Giảm 10% cho tuyến TP.HCM - Đà Lạt', discountType: 'Phần trăm', value: '10', startDate: '2025-10-01', endDate: '2025-10-31', status: 'Đang hoạt động', maxUsage: 1000, customerGroup: 'Tất cả' },
    { id: 'KM002', code: 'CHAOMUNG', description: 'Giảm 20,000đ cho khách hàng mới', discountType: 'Số tiền cố định', value: '20000', startDate: '2025-09-15', endDate: '2025-12-31', status: 'Đang hoạt động', maxUsage: 500, customerGroup: 'Khách hàng mới' },
    { id: 'KM003', code: 'SINHNHAT', description: 'Giảm 50,000đ trong tháng sinh nhật', discountType: 'Số tiền cố định', value: '50000', startDate: '2025-01-01', endDate: '2025-12-31', status: 'Đang hoạt động', maxUsage: 200, customerGroup: 'Khách hàng thân thiết' },
    { id: 'KM004', code: 'HE2025', description: 'Giảm giá vé hè', discountType: 'Phần trăm', value: '15', startDate: '2025-06-01', endDate: '2025-08-31', status: 'Đã hết hạn', maxUsage: 2000, customerGroup: 'Tất cả' },
];
// ----------------------------------

interface EditPageProps {
  params: { id: string }; // Lấy id từ thư mục [id]
}

export default function EditPromotionPage({ params }: EditPageProps) {
  const { id } = params;
  
  // State để lưu dữ liệu form
  const [formData, setFormData] = useState<any>(null);

  // Giả lập fetch dữ liệu khi component mount
  useEffect(() => {
    // (Ngoài đời thực, bạn sẽ fetch từ API)
    const data = mockPromotions.find(p => p.id === id);
    if (data) {
      setFormData(data);
    }
  }, [id]); // Chạy lại khi id thay đổi

  // Xử lý khi input thay đổi
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData((prev: any) => ({ ...prev, [name]: value }));
  };

  // TODO: Xử lý submit form (gọi API, Server Action)
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    alert('Đã cập nhật!');
    // console.log(formData);
  };

  // Hiển thị loading trong khi chờ "fetch"
  if (!formData) {
    return (
      <div className={styles.card}>
        <div className={styles.header}>
          <h1 className={styles.title}>Đang tải dữ liệu...</h1>
        </div>
      </div>
    );
  }

  return (
    <div className={styles.card}>
      <div className={styles.header}>
        <h1 className={styles.title}>Chỉnh sửa Khuyến mãi: {formData.code}</h1>
      </div>
      
      <form className={styles.form} onSubmit={handleSubmit}>
        <div className={styles.grid}>
          
          <div className={styles.formGroup}>
            <label htmlFor="code" className={styles.label}>Mã Code</label>
            <input type="text" id="code" name="code" className={styles.input} required 
              value={formData.code} onChange={handleChange}
            />
          </div>
          
          <div className={styles.formGroup}>
            <label htmlFor="discountType" className={styles.label}>Loại giảm giá</label>
            <select id="discountType" name="discountType" className={styles.select}
              value={formData.discountType} onChange={handleChange}
            >
              <option value="Phần trăm">Phần trăm (%)</option>
              <option value="Số tiền cố định">Số tiền cố định (VND)</option>
            </select>
          </div>

          <div className={styles.formGroup}>
            <label htmlFor="value" className={styles.label}>Giá trị</label>
            <input type="number" id="value" name="value" className={styles.input} required 
              value={formData.value} onChange={handleChange}
            />
          </div>

          <div className={styles.formGroup}>
            <label htmlFor="maxUsage" className={styles.label}>Số lượng tối đa</label>
            <input type="number" id="maxUsage" name="maxUsage" className={styles.input} 
              value={formData.maxUsage} onChange={handleChange}
            />
          </div>

          <div className={styles.formGroup}>
            <label htmlFor="startDate" className={styles.label}>Ngày bắt đầu</label>
            <input type="date" id="startDate" name="startDate" className={styles.input} required 
              value={formData.startDate} onChange={handleChange}
            />
          </div>

          <div className={styles.formGroup}>
            <label htmlFor="endDate" className={styles.label}>Ngày kết thúc</label>
            <input type="date" id="endDate" name="endDate" className={styles.input} required 
              value={formData.endDate} onChange={handleChange}
            />
          </div>

          <div className={styles.formGroup}>
            <label htmlFor="customerGroup" className={styles.label}>Nhóm khách hàng</label>
            <select id="customerGroup" name="customerGroup" className={styles.select}
              value={formData.customerGroup} onChange={handleChange}
            >
              <option value="Tất cả">Tất cả</option>
              <option value="Khách hàng mới">Khách hàng mới</option>
              <option value="Khách hàng thân thiết">Khách hàng thân thiết</option>
            </select>
          </div>

          <div className={styles.formGroupFull}>
            <label htmlFor="description" className={styles.label}>Mô tả</label>
            <textarea id="description" name="description" className={styles.textarea} required 
              value={formData.description} onChange={handleChange}
            />
          </div>
          
          {/* Nút Hành động */}
          <div className={styles.actions}>
            <Link href="/admin/promotions" className={`${styles.button} ${styles.cancelButton}`}>
              Hủy
            </Link>
            <button type="submit" className={`${styles.button} ${styles.saveButton}`}>
              Cập nhật
            </button>
          </div>
          
        </div>
      </form>
    </div>
  );
}