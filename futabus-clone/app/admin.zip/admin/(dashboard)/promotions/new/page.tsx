// app/admin/(dashboard)/promotions/new/page.tsx
"use client"; 
import React from 'react';
import Link from 'next/link';
// Sửa đường dẫn import
import styles from '../../../promotions/form.module.css'; 

export default function CreatePromotionPage() {
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    alert('Đã gửi form!');
  };

  return (
    <div className={styles.card}>
      <div className={styles.header}><h1 className={styles.title}>Tạo Khuyến mãi mới</h1></div>
      <form className={styles.form} onSubmit={handleSubmit}>
        <div className={styles.grid}>
          <div className={styles.formGroup}><label htmlFor="code" className={styles.label}>Mã Code</label><input type="text" id="code" name="code" className={styles.input} required /></div>
          <div className={styles.formGroup}><label htmlFor="discountType" className={styles.label}>Loại giảm giá</label><select id="discountType" name="discountType" className={styles.select}><option value="Phần trăm">Phần trăm (%)</option><option value="Số tiền cố định">Số tiền cố định (VND)</option></select></div>
          <div className={styles.formGroup}><label htmlFor="value" className={styles.label}>Giá trị</label><input type="number" id="value" name="value" className={styles.input} required /></div>
          <div className={styles.formGroup}><label htmlFor="maxUsage" className={styles.label}>Số lượng tối đa</label><input type="number" id="maxUsage" name="maxUsage" className={styles.input} /></div>
          <div className={styles.formGroup}><label htmlFor="startDate" className={styles.label}>Ngày bắt đầu</label><input type="date" id="startDate" name="startDate" className={styles.input} required /></div>
          <div className={styles.formGroup}><label htmlFor="endDate" className={styles.label}>Ngày kết thúc</label><input type="date" id="endDate" name="endDate" className={styles.input} required /></div>
          <div className={styles.formGroup}><label htmlFor="customerGroup" className={styles.label}>Nhóm khách hàng</label><select id="customerGroup" name="customerGroup" className={styles.select}><option value="Tất cả">Tất cả</option><option value="Khách hàng mới">Khách hàng mới</option><option value="Khách hàng thân thiết">Khách hàng thân thiết</option></select></div>
          <div className={styles.formGroupFull}><label htmlFor="description" className={styles.label}>Mô tả</label><textarea id="description" name="description" className={styles.textarea} required /></div>
          <div className={styles.actions}>
            <Link href="/admin/promotions" className={`${styles.button} ${styles.cancelButton}`}>Hủy</Link>
            <button type="submit" className={`${styles.button} ${styles.saveButton}`}>Lưu Khuyến mãi</button>
          </div>
        </div>
      </form>
    </div>
  );
}