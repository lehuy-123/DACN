// app/admin/vehicles/[id]/page.tsx
import React from 'react';
import Link from 'next/link';
import styles from '../detail.module.css';
import { FaArrowLeft } from 'react-icons/fa';

async function getVehicleDetails(id: string) {
  const mockVehicles = [
    { id: 'XE001', licensePlate: '51F-123.45', type: 'Giường nằm 40 chỗ', driver: 'Nguyễn Văn A', status: 'Đang hoạt động' },
    { id: 'XE002', licensePlate: '29B-987.65', type: 'Ghế ngồi 29 chỗ', driver: 'Trần Thị B', status: 'Đang hoạt động' },
    { id: 'XE003', licensePlate: '43A-987.65', type: 'Giường nằm 40 chỗ', driver: 'N/A', status: 'Đang bảo trì' },
    { id: 'XE004', licensePlate: '92A-112.33', type: 'Limousine 16 chỗ', driver: 'N/A', status: 'Ngưng hoạt động' },
  ];
  const vehicle = mockVehicles.find(p => p.id === id);
  await new Promise(resolve => setTimeout(resolve, 100));
  return vehicle;
}

interface DetailPageProps { params: { id: string }; }

export default async function VehicleDetailPage({ params }: DetailPageProps) {
  const { id } = await params;
  const vehicle = await getVehicleDetails(id);

  if (!vehicle) {
    return ( <div className={styles.container}><h1 className={styles.title}>Lỗi: Không tìm thấy xe</h1></div> );
  }

  let statusClass;
  if (vehicle.status === 'Đang hoạt động') statusClass = styles.active;
  if (vehicle.status === 'Đang bảo trì') statusClass = styles.maintenance;
  if (vehicle.status === 'Ngưng hoạt động') statusClass = styles.inactive;

  return (
    <div className={styles.container}>
      <Link href="/admin/vehicles" className={styles.backIconLink} title="Quay lại danh sách"><FaArrowLeft /></Link>
      <div className={styles.card}>
        <div className={styles.header}>
          <h1 className={styles.title}>Chi tiết Xe: {vehicle.licensePlate}</h1>
        </div>
        <div className={styles.content}>
          <div className={styles.grid}>
            <div><label className={styles.label}>Mã xe</label><p className={styles.value}>{vehicle.id}</p></div>
            <div><label className={styles.label}>Biển số</label><p className={styles.valueCode}>{vehicle.licensePlate}</p></div>
            <div><label className={styles.label}>Loại xe</label><p className={styles.value}>{vehicle.type}</p></div>
            <div><label className={styles.label}>Tài xế hiện tại</label><p className={styles.value}>{vehicle.driver}</p></div>
            <div><label className={styles.label}>Trạng thái</label><span className={`${styles.status} ${statusClass}`}>{vehicle.status}</span></div>
          </div>
        </div>
      </div>
    </div>
  );
}