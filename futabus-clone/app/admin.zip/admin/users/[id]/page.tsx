// app/admin/users/[id]/page.tsx
import React from 'react';
import Link from 'next/link';
import styles from '../detail.module.css';
import { FaArrowLeft } from 'react-icons/fa';

async function getUserDetails(id: string) {
  const mockUsers = [
    { id: '1', name: 'Nguyễn Văn A', email: 'nguyenvana@email.com', role: 'Admin', joinDate: '2023-10-01' },
    { id: '2', name: 'Trần Thị B', email: 'tranthib@email.com', role: 'User', joinDate: '2023-10-05' },
    { id: '3', name: 'Lê Văn C', email: 'levanc@email.com', role: 'User', joinDate: '2023-10-12' },
    { id: '4', name: 'Phạm Thị D', email: 'phamthid@email.com', role: 'Editor', joinDate: '2023-11-20' },
    { id: '5', name: 'Hoàng Văn E', email: 'hoangvane@email.com', role: 'User', joinDate: '2023-11-25' },
    { id: '6', name: 'Đỗ Thị F', email: 'dothif@email.com', role: 'User', joinDate: '2023-12-01' },
  ];
  const user = mockUsers.find(p => p.id === id);
  await new Promise(resolve => setTimeout(resolve, 100));
  return user;
}

interface DetailPageProps { params: { id: string }; }

export default async function UserDetailPage({ params }: DetailPageProps) {
  const { id } = await params;
  const user = await getUserDetails(id);

  if (!user) {
    return (<div className={styles.container}><h1 className={styles.title}>Lỗi: Không tìm thấy người dùng</h1></div>);
  }

  const roleClass = styles[user.role.toLowerCase()] || styles.user;

  return (
    <div className={styles.container}>
      <Link href="/admin/users" className={styles.backIconLink} title="Quay lại danh sách"><FaArrowLeft /></Link>
      <div className={styles.card}>
        <div className={styles.header}>
          <h1 className={styles.title}>Chi tiết Người dùng</h1>
        </div>
        <div className={styles.content}>
          <div className={styles.grid}>
            <div><label className={styles.label}>ID Người dùng</label><p className={styles.value}>{user.id}</p></div>
            <div><label className={styles.label}>Họ và Tên</label><p className={styles.value}>{user.name}</p></div>
            <div><label className={styles.label}>Email</label><p className={styles.value}>{user.email}</p></div>
            <div><label className={styles.label}>Ngày tham gia</label><p className={styles.value}>{user.joinDate}</p></div>
            <div><label className={styles.label}>Vai trò</label><span className={`${styles.role} ${roleClass}`}>{user.role}</span></div>
          </div>
        </div>
      </div>
    </div>
  );
}