// app/admin/_components/ReportDatePicker.tsx
"use client";
import React, { useState } from 'react';
import { usePathname, useRouter, useSearchParams } from 'next/navigation';
import DatePicker from 'react-datepicker';
import "react-datepicker/dist/react-datepicker.css";
import styles from '../reports/report.module.css';

// Hàm helper để format ngày YYYY-MM-DD
function formatDate(date: Date) {
  return date.toISOString().split('T')[0];
}

export default function ReportDatePicker() {
  const searchParams = useSearchParams();
  const pathname = usePathname();
  const { replace } = useRouter();

  // Lấy ngày từ URL, nếu không có thì dùng 30 ngày trước
  const defaultEndDate = new Date();
  const defaultStartDate = new Date();
  defaultStartDate.setDate(defaultStartDate.getDate() - 30);

  const [startDate, setStartDate] = useState(
    searchParams.get('from') ? new Date(searchParams.get('from')!) : defaultStartDate
  );
  const [endDate, setEndDate] = useState(
    searchParams.get('to') ? new Date(searchParams.get('to')!) : defaultEndDate
  );

  const handleDateChange = () => {
    const params = new URLSearchParams(searchParams);
    params.set('from', formatDate(startDate));
    params.set('to', formatDate(endDate));
    replace(`${pathname}?${params.toString()}`);
  };

  return (
    <div className={styles.datePicker}>
      <DatePicker
        selected={startDate}
        onChange={(date: Date) => setStartDate(date)}
        selectsStart
        startDate={startDate}
        endDate={endDate}
        className={styles.dateInput}
        dateFormat="yyyy-MM-dd"
      />
      <DatePicker
        selected={endDate}
        onChange={(date: Date) => setEndDate(date)}
        selectsEnd
        startDate={startDate}
        endDate={endDate}
        minDate={startDate}
        className={styles.dateInput}
        dateFormat="yyyy-MM-dd"
      />
      <button onClick={handleDateChange} style={{padding: '10px 16px', border: 'none', borderRadius: '6px', backgroundColor: '#F26522', color: 'white', cursor: 'pointer'}}>
        Lọc
      </button>
    </div>
  );
}   