// app/admin/_components/StatisticCard.tsx
'use client'; 
import React from 'react';
import Link from 'next/link';
// SỬA: Không cần import IconType nữa
import styles from '../overview.module.css'; 

interface CardProps {
  title: string;
  value: string;
  icon: React.ReactNode; // SỬA: Đổi từ IconType sang React.ReactNode
  href: string;
  color: string;
}

// SỬA: Bỏ icon: Icon và chỉ dùng {icon}
export default function StatisticCard({ title, value, icon, href, color }: CardProps) {
  return (
    <Link href={href} className={styles.statCard} style={{ textDecoration: 'none' }}>
      <div className={styles.cardIcon} style={{ backgroundColor: color }}>
        {/* SỬA: Chỉ cần render {icon} */}
        {icon}
      </div>
      <div className={styles.cardInfo}>
        <span className={styles.cardTitle}>{title}</span>
        <span className={styles.cardValue}>{value}</span>
      </div>
    </Link>
  );
}