// app/admin/_components/Pagination.tsx
'use client';

import { usePathname, useSearchParams, useRouter } from 'next/navigation';
import styles from '../admin-ui.module.css'; // Dùng chung file CSS
import { FaArrowLeft, FaArrowRight } from 'react-icons/fa';

export default function Pagination({ totalPages }: { totalPages: number }) {
  const pathname = usePathname();
  const searchParams = useSearchParams();
  const { replace } = useRouter();
  const currentPage = Number(searchParams.get('page')) || 1;

  const createPageURL = (pageNumber: number | string) => {
    const params = new URLSearchParams(searchParams);
    params.set('page', pageNumber.toString());
    return `${pathname}?${params.toString()}`;
  };

  return (
    <div className={styles.pagination}>
      <button
        className={styles.paginationButton}
        onClick={() => replace(createPageURL(currentPage - 1))}
        disabled={currentPage <= 1}
        title="Trang trước"
      >
        {/* ĐÃ XÓA CHỮ "TRƯỚC" */}
        <FaArrowLeft />
      </button>
      
      <div className={styles.paginationInfo}>
        Trang {currentPage} / {totalPages}
      </div>

      <button
        className={styles.paginationButton}
        onClick={() => replace(createPageURL(currentPage + 1))}
        disabled={currentPage >= totalPages}
        title="Trang sau"
      >
        {/* ĐÃ XÓA CHỮ "SAU" */}
        <FaArrowRight />
      </button>
    </div>
  );
}