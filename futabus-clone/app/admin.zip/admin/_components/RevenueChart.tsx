// app/admin/_components/RevenueChart.tsx
"use client"; // Biểu đồ cần 'use client'
import React from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import styles from '../overview.module.css';

// Dữ liệu giả
const data = [
  { name: '7 ngày trước', DoanhThu: 2_100_000 },
  { name: '6 ngày trước', DoanhThu: 3_500_000 },
  { name: '5 ngày trước', DoanhThu: 2_900_000 },
  { name: '4 ngày trước', DoanhThu: 4_200_000 },
  { name: '3 ngày trước', DoanhThu: 3_100_000 },
  { name: 'Hôm qua', DoanhThu: 5_300_000 },
  { name: 'Hôm nay', DoanhThu: 15_200_000 },
];

const formatCurrency = (tickItem: number) => {
  return (tickItem / 1_000_000).toLocaleString('vi-VN') + 'tr';
};

export default function RevenueChart() {
  return (
    <div className={styles.chartWrapper}>
      <ResponsiveContainer width="100%" height={300}>
        <LineChart data={data}>
          <CartesianGrid strokeDasharray="3 3" stroke="#e0e0e0" />
          <XAxis dataKey="name" fontSize={12} />
          <YAxis fontSize={12} tickFormatter={formatCurrency} />
          <Tooltip 
            formatter={(value: number) => 
              `${value.toLocaleString('vi-VN')}đ`
            } 
          />
          <Legend />
          <Line 
            type="monotone" 
            dataKey="DoanhThu" 
            stroke="#0d6efd" 
            strokeWidth={2} 
            activeDot={{ r: 8 }} 
          />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}