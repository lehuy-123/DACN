// app/admin/invoices/[id]/page.tsx
import React from 'react';
import Link from 'next/link';
import styles from '../detail.module.css';
import { FaArrowLeft } from 'react-icons/fa';
import PrintButton from '../_components/PrintButton'; // Import nút in

async function getInvoiceDetails(id: string) {
  const mockInvoices = [
    { id: 'HD001', customerName: 'Nguyễn Văn A', tripInfo: 'TP. HCM - Đà Lạt', total: 250000, date: '2025-10-20', status: 'Đã thanh toán' },
    { id: 'HD002', customerName: 'Trần Thị B', tripInfo: 'Hà Nội - Hải Phòng', total: 100000, date: '2025-10-22', status: 'Chưa thanh toán' },
    { id: 'HD003', customerName: 'Lê Văn C', tripInfo: 'Đà Nẵng - Huế', total: 70000, date: '2025-10-15', status: 'Đã hủy' },
  ];
  const invoice = mockInvoices.find(p => p.id === id);
  await new Promise(resolve => setTimeout(resolve, 100));
  return invoice;
}

interface DetailPageProps { params: { id: string }; }

export default async function InvoiceDetailPage({ params }: DetailPageProps) {
  const { id } = await params;
  const invoice = await getInvoiceDetails(id);

  if (!invoice) {
    return (
      <div className={styles.container}>
        <h1 className={styles.title}>Lỗi: Không tìm thấy hóa đơn: {id}</h1>
        <Link href="/admin/invoices" className={styles.backIconLink} title="Quay lại danh sách"><FaArrowLeft /></Link>
      </div>
    );
  }

  let statusClass = styles.pending;
  if (invoice.status === 'Đã thanh toán') statusClass = styles.paid;
  if (invoice.status === 'Đã hủy') statusClass = styles.cancelled;

  return (
    <div className={styles.container}>
      <Link href="/admin/invoices" className={styles.backIconLink} title="Quay lại danh sách"><FaArrowLeft /></Link>

      <div className={styles.card}>
        <div className={styles.header}>
          <h1 className={styles.title}>Hóa đơn: {invoice.id}</h1>
          <PrintButton /> {/* Nút In (Client Component) */}
        </div>

        <div className={styles.content}>
          <div className={styles.grid}>

            <div className={styles.valueFull}>
              <label className={styles.label}>Trạng thái</label>
              <span className={`${styles.status} ${statusClass}`}>{invoice.status}</span>
            </div>

            <div>
              <label className={styles.label}>Tên khách hàng</label>
              <p className={styles.value}>{invoice.customerName}</p>
            </div>
            <div>
              <label className={styles.label}>Ngày đặt</label>
              <p className={styles.value}>{invoice.date}</p>
            </div>

            <div className={styles.valueFull}>
              <label className={styles.label}>Thông tin chuyến đi</label>
              <p className={styles.value}>{invoice.tripInfo}</p>
            </div>

            <div className={styles.valueFull}>
              <label className={styles.label}>Tổng tiền</label>
              <p className={`${styles.value} ${styles.total}`}>
                {invoice.total.toLocaleString('vi-VN')}đ
              </p>
            </div>

          </div>
        </div>
      </div>
    </div>
  );
}