// app/admin/routes/[id]/page.tsx
import React from 'react';
import Link from 'next/link';
import styles from '../detail.module.css';
import { FaArrowLeft } from 'react-icons/fa';

async function getRouteDetails(id: string) {
  const mockRoutes = [
    { id: 'ROUTE01', name: 'TP. HCM - Đà Lạt', start: 'Bến xe Miền Đông', end: 'Bến xe Liên tỉnh Đà Lạt', distance: '308 km', time: '8 giờ' },
    { id: 'ROUTE02', name: 'TP. HCM - Vũng Tàu', start: 'Bến xe Miền Đông', end: 'Bến xe Vũng Tàu', distance: '96 km', time: '2.5 giờ' },
  ];
  const route = mockRoutes.find(p => p.id === id);
  await new Promise(resolve => setTimeout(resolve, 100));
  return route;
}

interface DetailPageProps { params: { id: string }; }

export default async function RouteDetailPage({ params }: DetailPageProps) {
  const { id } = await params;
  const route = await getRouteDetails(id);

  if (!route) {
    return ( <div className={styles.container}><h1 className={styles.title}>Lỗi: Không tìm thấy tuyến xe</h1></div> );
  }

  return (
    <div className={styles.container}>
      <Link href="/admin/routes" className={styles.backIconLink} title="Quay lại danh sách"><FaArrowLeft /></Link>
      <div className={styles.card}>
        <div className={styles.header}>
          <h1 className={styles.title}>Chi tiết Tuyến xe</h1>
        </div>
        <div className={styles.content}>
          <div className={styles.grid}>
            <div><label className={styles.label}>Mã tuyến</label><p className={styles.valueCode}>{route.id}</p></div>
            <div><label className={styles.label}>Tên tuyến</label><p className={styles.value}>{route.name}</p></div>
            <div><label className={styles.label}>Điểm đi</label><p className={styles.value}>{route.start}</p></div>
            <div><label className={styles.label}>Điểm đến</label><p className={styles.value}>{route.end}</p></div>
            <div><label className={styles.label}>Khoảng cách</label><p className={styles.value}>{route.distance}</p></div>
            <div><label className={styles.label}>Thời gian ước tính</label><p className={styles.value}>{route.time}</p></div>
          </div>
        </div>
      </div>
    </div>
  );
}