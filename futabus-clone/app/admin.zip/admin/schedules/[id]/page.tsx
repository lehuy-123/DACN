// app/admin/schedules/[id]/page.tsx
import React from 'react';
import Link from 'next/link';
import styles from '../detail.module.css';
import { FaArrowLeft } from 'react-icons/fa';

async function getScheduleDetails(id: string) {
  const mockSchedules = [
    { id: 'SG-DL-01', route: 'TP. HCM - Đà Lạt', vehicle: '51F-123.45', startTime: '2025-10-28 22:00', endTime: '2025-10-29 06:00', seats: '30/40', status: 'Sắp khởi hành' },
    { id: 'HN-HP-05', route: 'Hà Nội - Hải Phòng', vehicle: '29B-543.21', startTime: '2025-10-28 18:30', endTime: '2025-10-28 20:30', seats: '15/29', status: 'Đang chạy' },
  ];
  const schedule = mockSchedules.find(p => p.id === id);
  await new Promise(resolve => setTimeout(resolve, 100));
  return schedule;
}

interface DetailPageProps { params: { id: string }; }

export default async function ScheduleDetailPage({ params }: DetailPageProps) {
  const { id } = await params;
  const schedule = await getScheduleDetails(id);

  if (!schedule) {
    return ( <div className={styles.container}><h1 className={styles.title}>Lỗi: Không tìm thấy lịch trình</h1></div> );
  }

  let statusClass;
  if (schedule.status === 'Sắp khởi hành') statusClass = styles.upcoming;
  if (schedule.status === 'Đang chạy') statusClass = styles.running;
  if (schedule.status === 'Hoàn thành') statusClass = styles.completed;
  if (schedule.status === 'Đã hủy') statusClass = styles.cancelled;

  return (
    <div className={styles.container}>
      <Link href="/admin/schedules" className={styles.backIconLink} title="Quay lại danh sách"><FaArrowLeft /></Link>
      <div className={styles.card}>
        <div className={styles.header}>
          <h1 className={styles.title}>Chi tiết Lịch trình</h1>
        </div>
        <div className={styles.content}>
          <div className={styles.grid}>
            <div><label className={styles.label}>Mã chuyến</label><p className={styles.valueCode}>{schedule.id}</p></div>
            <div><label className={styles.label}>Tuyến xe</label><p className={styles.value}>{schedule.route}</p></div>
            <div><label className={styles.label}>Biển số xe</label><p className={styles.value}>{schedule.vehicle}</p></div>
            <div><label className={styles.label}>Giờ khởi hành</label><p className={styles.value}>{schedule.startTime}</p></div>
            <div><label className={styles.label}>Dự kiến đến</label><p className={styles.value}>{schedule.endTime}</p></div>
            <div><label className={styles.label}>Số ghế (Đã đặt/Tổng)</label><p className={styles.value}>{schedule.seats}</p></div>
            <div><label className={styles.label}>Trạng thái</label><span className={`${styles.status} ${statusClass}`}>{schedule.status}</span></div>
          </div>
        </div>
      </div>
    </div>
  );
}